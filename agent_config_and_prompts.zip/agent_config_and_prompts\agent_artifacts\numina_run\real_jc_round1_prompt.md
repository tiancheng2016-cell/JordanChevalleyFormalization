This is the Jordan-Chevalley decomposition formalization task.

You are running through Numina-Lean-Agent via a Codex wrapper for one controlled round only.

Work only on `Formalization.lean` in the current Lean project directory.
Do not edit `Formalization.lean.bak_step8ea`.
Do not edit `NuminaAdapterToy.lean`.
Do not edit any files outside this Lean project.

Target theorem:

```lean
AI4MATH.jordan_chevalley_decomposition
```

Required preservation:

- Preserve the theorem name `AI4MATH.jordan_chevalley_decomposition`.
- Preserve the mathematical meaning of the theorem statement.
- Do not weaken the theorem statement.
- Keep the finite-dimensional vector space hypothesis.
- Keep the algebraically closed field hypothesis.
- Keep `T : Module.End K V`.
- Keep existence of `S N`.
- Keep `T = S + N`.
- Keep `S.IsSemisimple`.
- Keep `IsNilpotent N`.
- Keep `Commute S N`.
- Keep both polynomial-in-`T` membership goals:
  `S ∈ Algebra.adjoin K ({T} : Set (Module.End K V))`
  and
  `N ∈ Algebra.adjoin K ({T} : Set (Module.End K V))`.
- Keep the uniqueness clause for any `S' N'` satisfying the same decomposition conditions.

Strict forbidden rules:

- Do not import `Mathlib.LinearAlgebra.JordanChevalley`.
- Do not use `Module.End.exists_isNilpotent_isSemisimple`.
- Do not use `Module.End.isNilpotent_isSemisimple_unique`.
- Do not use `Module.End.exists_isNilpotent_isSemisimple_of_separable_of_dvd_pow`.
- Do not use any theorem, lemma, alias, wrapper, or import that directly states Jordan-Chevalley decomposition, Jordan-Chevalley-Dunford decomposition, Dunford decomposition, existence of a semisimple plus nilpotent decomposition, or uniqueness of such a decomposition.
- Do not introduce custom `axiom`, `constant`, or `unsafe`.
- Do not use `admit`.

Proof strategy and allowed material:

- Follow `../inputs/blueprint.md`.
- Use only lower-level Mathlib building blocks recorded in `../logs/MATHLIB_BUILDING_BLOCKS.md`.
- Prefer adding helper lemmas above the theorem if useful.
- Allowed themes include `LinearMap`, `Module.End`, `Submodule`, `Polynomial`, `Ideal`, finite-dimensional vector spaces, kernels, direct sums, polynomial evaluation on endomorphisms, nilpotent maps, semisimple/diagonalizable definitions, generalized eigenspaces, and ordinary tactics.

Workflow:

1. Inspect the existing imports and theorem statement.
2. Make conservative Lean edits only in `Formalization.lean`.
3. After edits, run:

```text
lake env lean Formalization.lean
```

4. Also check that no forbidden names were introduced:

```text
rg -n "Mathlib.LinearAlgebra.JordanChevalley|exists_isNilpotent_isSemisimple|isNilpotent_isSemisimple_unique|exists_isNilpotent_isSemisimple_of_separable_of_dvd_pow|Dunford" Formalization.lean
```

5. Check placeholders / unsafe declarations:

```text
rg -n "sorry|admit|axiom|constant|unsafe" Formalization.lean
```

End protocol:

- Use `END_REASON:COMPLETE` only if `Formalization.lean` has no Lean errors, no `sorry`, no `admit`, no custom `axiom`, no custom `constant`, no `unsafe`, and no forbidden theorem/import usage.
- If the full theorem cannot be completed in this one round, make honest partial progress while preserving the theorem statement and end with `END_REASON:LIMIT`.
