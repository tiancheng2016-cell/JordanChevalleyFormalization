# Step 8D-A Numina Codex Backend Investigation

## Current Goal

Investigate whether Numina-Lean-Agent can be repointed from Claude Code to Codex for the Jordan-Chevalley Lean project, without modifying `lean_project/Formalization.lean` and without running a proof loop.

## Numina From Class Notes

The class PDF `inputs/numina.pdf` describes Numina-Lean-Agent as another harness for the same basic agent loop as Archon: generate -> verify -> repair -> accept, with the Lean kernel deciding correctness.

Important notes extracted from the PDF:

- Numina turns a natural-language blueprint into Lean code checked by the Lean kernel.
- The described loop is `scripts.run_claude`.
- Each round launches headless Claude Code on a `.lean` file.
- The notes mention Lean diagnostics through `lean-lsp-mcp` and `lean_diagnostic_messages`.
- The loop uses end reasons such as `END_REASON:LIMIT` and `END_REASON:COMPLETE`.
- `--max-rounds N` bounds the number of rounds.
- Config examples include `allow_sorry: false`.
- With `git_commit: true`, the runner commits after every round for recoverability.
- Final verification is done with `lake env lean`.
- The final report should include `#print axioms`; the example checks that no `sorryAx` remains.

## Source Location

No Numina source was present locally before this step. Local recursive searches found only:

- `inputs/numina.pdf`
- the newly created folder `agent_artifacts/numina_run/`

The official source was identified from the Numina paper/search result:

- `https://github.com/project-numina/numina-lean-agent`
- `https://arxiv.org/abs/2601.14027`

It was cloned into:

- `agent_artifacts/numina_run/numina-lean-agent/`

The repository README says it is "built on Claude Code for formal theorem proving tasks" and its setup guide installs/configures Claude Code.

## Codex CLI Availability

Codex is available locally:

```text
where.exe codex
c:\Users\tianc\.vscode\extensions\openai.chatgpt-26.609.30741-win32-x64\bin\windows-x86_64\codex.exe

codex.cmd --version
codex-cli 0.132.0
```

`codex.cmd exec --help` confirms non-interactive execution:

- prompt can be passed as an argument;
- prompt can be read from stdin with `-`;
- `--cd <DIR>` sets the working directory;
- `--json` prints JSONL events to stdout;
- `--output-last-message <FILE>` writes the final assistant message;
- `--model <MODEL>` selects the Codex model.

`codex.cmd exec resume --help` confirms session resume support:

- `codex exec resume [SESSION_ID] [PROMPT]`;
- `--last` resumes the most recent session;
- it also supports stdin with `-` and JSONL output with `--json`.

## Numina Backend Architecture

Numina has a centralized runner:

- CLI entry point: `scripts/run_claude.py`
- task metadata/config: `scripts/task.py`
- core subprocess loop: `scripts/runner.py`
- Lean checker: `scripts/lean_checker.py`

Important source findings:

- `scripts/run_claude.py` exposes `run`, `batch`, and `from_folder`.
- `scripts/task.py` has `max_rounds`, `allow_sorry`, `permission_mode`, `git_commit`, `result_dir`, and statement tracking fields.
- `scripts/runner.py` hardcodes the coding-agent command as:

```text
claude -p --verbose --output-format stream-json
claude -c -p --verbose --output-format stream-json continue
```

- `scripts/runner.py` expects Claude stream JSONL and parses the final JSON line with `type == "result"`.
- It reads the final result text from the JSON field `result`.
- It detects loop status by matching `END_REASON:LIMIT`, `END_REASON:COMPLETE`, or `END_REASON:SELECTED_TARGET_COMPLETE`.
- `scripts/lean_checker.py` verifies files using `lake env lean <file>`.
- If `allow_sorry` is false, sorry warnings are treated as verification failures.
- `git_commit: true` creates a git commit after each round.

The cloned repository does not appear to call `lean-lsp-mcp` directly in the core Python runner. Searches found `mcp` in `uv.lock` and prompt/docs references to `lean_diagnostic_messages`, but the visible final checker is `lake env lean`.

## Native Codex Backend Configuration

Native Codex backend support was not found.

Findings:

- `rg -n "codex|Codex" .` in the Numina repository returned no matches.
- No config field was found for choosing the coding-agent executable.
- No CLI flag was found for replacing `claude` with `codex.cmd`.
- `permission_mode` is passed to Claude Code and is not a backend selector.
- OpenAI/Gemini keys in the README are for optional CLI skills such as informal/discussion helpers, not for the main coding-agent backend.

Therefore, Numina does not currently support Codex through native config in this checkout.

## Patch Feasibility

Classification: Wrapper adapter likely possible.

Reason:

- The main coding-agent subprocess call is centralized in `scripts/runner.py`.
- The runner mostly needs a JSONL file whose final nonempty line is a JSON object with `type: "result"` and a `result` string containing an `END_REASON`.
- Codex already supports non-interactive execution, working-directory selection, JSONL output, and session resume.
- A wrapper named like `claude` could translate Numina's expected Claude CLI shape into `codex.cmd exec` calls and emit a Claude-like final result JSON line.

This is not native config, and it is not zero-risk. A direct string replacement of `claude` with `codex.cmd` is not sufficient because Numina expects Claude flags and Claude stream-json schema.

## Risks

- Codex JSONL event schema differs from Claude stream-json.
- Numina expects the final JSON line to have `type: "result"` and `result`.
- Numina's continuation path uses `claude -c -p continue`; this would need mapping to `codex exec resume --last continue` or another reliable resume strategy.
- The existing prompts and setup assume Claude Code, `.claude/skills`, and Claude's Task/subagent affordances.
- Codex may not expose the same MCP/tool surface as Claude Code in this harness.
- The class notes mention `lean-lsp-mcp`, but this checkout's core runner visibly verifies through `lake env lean`; any MCP-dependent prompt behavior would need review.
- The source has a stale-looking reference to `self.mcp_log_dir` in `scripts/task.py`; this was not exercised, but it may need a small repair before running tasks.
- A wrapper must preserve `END_REASON` discipline so the loop knows whether to stop or continue.

## Recommended Next Route

N3: Create a wrapper adapter around `codex.cmd exec`.

This is more promising than the Archon patch because Numina's backend call is centralized and its loop protocol is relatively small. The next step should be to design a minimal adapter that accepts the Claude-shaped arguments Numina emits, calls `codex.cmd exec`, translates Codex output into the final Claude-like JSON result expected by `scripts/runner.py`, and does a dry run on a harmless toy Lean file before touching the Jordan-Chevalley theorem.
