# Step 8D-C Numina Codex Wrapper Dry Run

## Adapter Files Created

Created folders:

- `agent_artifacts/numina_run/wrappers/`
- `agent_artifacts/numina_run/wrappers/logs/`
- `agent_artifacts/numina_run/results/adapter_toy/`

Created adapter files:

- `agent_artifacts/numina_run/wrappers/claude_codex_adapter.py`
- `agent_artifacts/numina_run/wrappers/claude.cmd`

Created toy Numina artifacts:

- `agent_artifacts/numina_run/adapter_toy_prompt.md`
- `agent_artifacts/numina_run/adapter_toy_config.yaml`
- `lean_project/NuminaAdapterToy.lean`

The adapter accepts Numina's Claude-like arguments, logs ignored Claude-only flags, detects first vs continuation calls, invokes `codex.cmd exec` or `codex.cmd exec resume --last`, saves raw Codex logs, and always emits a final Claude-compatible JSON line with `type: "result"` and an `END_REASON`.

Two small backed-up compatibility patches were needed in the cloned Numina source:

- `scripts/task.py.bak_step8dc` was created before adding the missing `mcp_log_dir` dataclass field.
- `scripts/runner.py.bak_step8dc` was created before adding `NUMINA_CLAUDE_EXE` / `NUMINA_CLAUDE_ADAPTER` overrides.

## Smoke Test Results

Adapter syntax check passed:

```text
python -m py_compile agent_artifacts\numina_run\wrappers\claude_codex_adapter.py
```

First-call smoke test command:

```text
agent_artifacts\numina_run\wrappers\claude.cmd -p --verbose --output-format stream-json --permission-mode bypassPermissions "Reply with END_REASON:LIMIT only."
```

Final successful smoke result:

```text
type: result
continuation: false
Codex invoked: yes
Codex return code: 0
END_REASON:LIMIT
```

Continuation-style smoke test command:

```text
agent_artifacts\numina_run\wrappers\claude.cmd -c -p --verbose --output-format stream-json --permission-mode bypassPermissions continue
```

Final successful smoke result:

```text
type: result
continuation: true
Codex invoked: yes
Codex return code: 0
END_REASON:LIMIT
```

Mechanical validation of the latest two adapter result files confirmed:

```text
type == result
result field present
END_REASON present
```

## Toy Lean File

Initial toy file:

```lean
import Mathlib

theorem numina_adapter_toy : True := by
  sorry
```

Direct initial Lean check:

```text
lake env lean NuminaAdapterToy.lean
NuminaAdapterToy.lean:3:8: warning: declaration uses `sorry`
```

Final toy file after the successful Numina/Codex dry run:

```lean
import Mathlib

theorem numina_adapter_toy : True := by
  trivial
```

Final direct Lean check on the toy file passed with no output:

```text
lake env lean NuminaAdapterToy.lean
```

## Numina Toy Dry Run Command

The final successful dry run used the direct Python adapter path to preserve multiline prompts:

```powershell
$env:PYTHONPATH='..\python_deps'
$wrapper=(Resolve-Path ..\wrappers).Path
$env:PATH="$wrapper;$env:PATH"
$env:NUMINA_CLAUDE_EXE='python'
$env:NUMINA_CLAUDE_ADAPTER=(Resolve-Path ..\wrappers\claude_codex_adapter.py).Path
python -m scripts.run_claude batch ..\adapter_toy_config.yaml
```

The target in `adapter_toy_config.yaml` was only:

```text
../../../lean_project/NuminaAdapterToy.lean
```

It did not target `Formalization.lean`.

## Numina Toy Dry Run Result

Several staged attempts were informative:

1. Initial Numina run failed before wrapper invocation because `TaskMetadata.__post_init__` referenced missing `self.mcp_log_dir`.
2. After backing up and patching `scripts/task.py`, a PATH-only shim attempt failed because Windows/Python did not resolve bare `claude` to `claude.cmd` inside `subprocess.Popen`.
3. After backing up and patching `scripts/runner.py`, setting `NUMINA_CLAUDE_EXE` directly to `claude.cmd` invoked the wrapper, but the `.cmd` layer truncated Numina's multiline prompt. That run ended with `END_REASON:LIMIT`, and Numina's final verification called its Lean checker and correctly failed the toy file because `allow_sorry: false` detected the remaining `sorry`.
4. The final successful run used `NUMINA_CLAUDE_EXE=python` and `NUMINA_CLAUDE_ADAPTER=<adapter.py>`, preserving the full prompt. Codex edited only `NuminaAdapterToy.lean`, replacing `sorry` with `trivial`.

Final successful Numina result:

```text
Task: file_NuminaAdapterToy_20260613_121931
Success: True
End reason: COMPLETE
Rounds used: 1
```

Codex adapter output inside Numina:

```text
[codex-adapter] invoked Codex: yes
[codex-adapter] continuation: false
[codex-adapter] codex return code: 0
Updated `NuminaAdapterToy.lean` only: replaced `sorry` with `trivial`.
END_REASON:COMPLETE
```

Note: with `max_rounds: 1`, Numina's successful `COMPLETE` path did not visibly print its verification callback before exiting. The earlier `LIMIT` run did visibly exercise Numina's final checker and `allow_sorry: false`. The final toy file was also checked directly with `lake env lean NuminaAdapterToy.lean`, which passed.

## Whether Formalization.lean Was Untouched

`lean_project/Formalization.lean` was not edited in this step.

Final check:

```text
lake env lean Formalization.lean
Formalization.lean:19:8: warning: declaration uses `sorry`
```

Forbidden-name search:

```text
rg -n "Mathlib.LinearAlgebra.JordanChevalley|exists_isNilpotent_isSemisimple|isNilpotent_isSemisimple_unique|exists_isNilpotent_isSemisimple_of_separable_of_dvd_pow|Dunford" Formalization.lean
```

Output:

```text
no matches
```

`git status --short` from this project folder is not a clean modification signal because the whole `JordanChevalleyFormalization/` folder appears as untracked under the parent repository, but no command in this step targeted or edited `Formalization.lean`.

## Remaining Blockers

No blocker remains for the toy adapter route.

Caveats for future real use:

- The `.cmd` shim works for one-line smoke tests but is not safe for Numina's multiline prompts.
- Use the direct Python adapter path through `NUMINA_CLAUDE_EXE=python` and `NUMINA_CLAUDE_ADAPTER=<adapter.py>` for future Numina runs.
- The cloned Numina runner needed two small backed-up compatibility patches.
- For real proof runs, keep final independent checks with `lake env lean`, placeholder searches, forbidden-name searches, and `#print axioms`.
- Consider using `max_rounds > 1` or adjusting Numina's runner order in a future step so `COMPLETE` verification is visibly run before the max-round guard.

## Recommendation

The wrapper adapter is viable for toy use. The next step, if approved, is to prepare a carefully constrained Numina/Codex run for the real theorem using the direct Python adapter path, not the `.cmd` shim, and to keep all final safety checks mandatory. Do not start the Jordan-Chevalley proof loop until explicitly requested.
