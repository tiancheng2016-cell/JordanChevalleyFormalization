# Optional Agent Config and Prompt Files

This folder contains the optional agent configuration, prompt, log, and verification artifacts for Assignment 2.

Codex was used as the agentic coding assistant. Numina-Lean-Agent was used as the Lean proving-agent harness through a local wrapper adapter, because the cloned Numina runner normally calls Claude Code. The wrapper translated Numina's Claude-shaped calls into `codex.cmd exec` calls and emitted the result format Numina expected.

Included items:

- prompt logs and prompt summaries under `logs/`;
- Archon-to-Codex investigation and decision logs under `logs/`;
- Numina-to-Codex investigation, wrapper plan, and dry-run logs under `logs/`;
- Round 1 and Round 2 real theorem prompt/config files under `agent_artifacts/numina_run/`;
- the Numina-to-Codex wrapper files under `agent_artifacts/numina_run/wrappers/`;
- final verification logs and exact `#print axioms` output.

Round 1 technically completed the theorem but was rejected because it used a suspicious Newton shortcut. Round 2 restored the backup, added stricter forbidden constraints, and produced the final accepted proof. Final verification was performed independently with Lean checks, placeholder/forbidden-name searches, and `#print axioms`.

No huge dependency folders such as `.lake/` or Numina Python dependency folders are included. No secrets, API keys, authentication tokens, or private credentials are intentionally included.

Missing requested files: none.
