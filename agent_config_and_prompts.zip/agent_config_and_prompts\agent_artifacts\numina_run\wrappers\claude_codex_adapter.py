#!/usr/bin/env python3
"""Translate Numina's Claude-shaped CLI calls into Codex exec calls.

This adapter is intentionally conservative: it only reports COMPLETE when
Codex itself returns an END_REASON:COMPLETE marker with exit code 0.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
LOG_DIR = ROOT / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

END_REASON_RE = re.compile(
    r"(?m)^\s*END_REASON:(LIMIT|COMPLETE|SELECTED_TARGET_COMPLETE)\s*$",
    re.IGNORECASE,
)


def append_jsonl(path: Path, obj: dict[str, Any]) -> None:
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def parse_claude_like_args(argv: list[str]) -> tuple[bool, str, list[dict[str, Any]]]:
    continuation = False
    positionals: list[str] = []
    ignored: list[dict[str, Any]] = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "-c":
            continuation = True
            ignored.append({"flag": arg})
            i += 1
        elif arg == "-p":
            ignored.append({"flag": arg})
            i += 1
        elif arg == "--verbose":
            ignored.append({"flag": arg})
            i += 1
        elif arg in {"--output-format", "--permission-mode"}:
            value = argv[i + 1] if i + 1 < len(argv) else None
            ignored.append({"flag": arg, "value": value})
            i += 2 if value is not None else 1
        elif arg.startswith("--output-format=") or arg.startswith("--permission-mode="):
            ignored.append({"flag": arg})
            i += 1
        else:
            positionals.append(arg)
            i += 1

    prompt = "\n".join(positionals).strip()
    if not prompt:
        prompt = "continue" if continuation else ""
    return continuation, prompt, ignored


def collect_strings(obj: Any) -> list[str]:
    strings: list[str] = []
    if isinstance(obj, str):
        strings.append(obj)
    elif isinstance(obj, dict):
        for value in obj.values():
            strings.extend(collect_strings(value))
    elif isinstance(obj, list):
        for value in obj:
            strings.extend(collect_strings(value))
    return strings


def extract_text_from_jsonl(text: str) -> str:
    pieces: list[str] = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        for s in collect_strings(obj):
            if s and len(s) < 20000:
                pieces.append(s)
    return "\n".join(pieces)


def decide_reason(codex_text: str, returncode: int) -> str:
    matches = [m.group(1).upper() for m in END_REASON_RE.finditer(codex_text)]
    if not matches:
        return "LIMIT"
    reason = matches[-1]
    if reason == "COMPLETE" and returncode == 0:
        return "COMPLETE"
    if reason == "SELECTED_TARGET_COMPLETE" and returncode == 0:
        return "SELECTED_TARGET_COMPLETE"
    return "LIMIT"


def build_codex_command(
    continuation: bool,
    cwd: Path,
    final_message_path: Path,
) -> list[str]:
    codex = shutil.which("codex.cmd") or shutil.which("codex") or "codex.cmd"
    common = [
        "--skip-git-repo-check",
        "--json",
        "--output-last-message",
        str(final_message_path),
    ]
    if continuation:
        return [codex, "exec", "resume", "--last", *common, "-"]
    return [codex, "exec", "--cd", str(cwd), "--sandbox", "workspace-write", *common, "-"]


def main() -> int:
    argv = sys.argv[1:]
    cwd = Path.cwd()
    run_id = time.strftime("%Y%m%d_%H%M%S") + "_" + str(os.getpid()) + "_" + uuid.uuid4().hex[:8]
    raw_stdout_path = LOG_DIR / f"codex_raw_{run_id}.jsonl"
    raw_stderr_path = LOG_DIR / f"codex_stderr_{run_id}.txt"
    final_message_path = LOG_DIR / f"codex_final_{run_id}.txt"
    result_path = LOG_DIR / f"adapter_result_{run_id}.json"

    continuation, prompt, ignored = parse_claude_like_args(argv)
    invocation = {
        "run_id": run_id,
        "argv": argv,
        "cwd": str(cwd),
        "continuation": continuation,
        "prompt_preview": prompt[:500],
        "ignored_claude_flags": ignored,
    }
    append_jsonl(LOG_DIR / "adapter_invocations.jsonl", invocation)

    command = build_codex_command(continuation, cwd, final_message_path)
    codex_invoked = False
    returncode = 1
    stdout = ""
    stderr = ""
    error_text = ""

    try:
        codex_invoked = True
        proc = subprocess.run(
            command,
            input=prompt,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            cwd=str(cwd),
            timeout=int(os.environ.get("CODEX_ADAPTER_TIMEOUT", "600")),
        )
        returncode = proc.returncode
        stdout = proc.stdout or ""
        stderr = proc.stderr or ""
    except Exception as exc:
        error_text = f"{type(exc).__name__}: {exc}"

    raw_stdout_path.write_text(stdout, encoding="utf-8")
    raw_stderr_path.write_text(stderr + (("\n" + error_text) if error_text else ""), encoding="utf-8")

    final_text = ""
    if final_message_path.exists():
        final_text = final_message_path.read_text(encoding="utf-8", errors="replace").strip()
    if not final_text:
        final_text = extract_text_from_jsonl(stdout).strip()
    if not final_text:
        final_text = stdout.strip()
    if not final_text and stderr.strip():
        final_text = stderr.strip()
    if not final_text and error_text:
        final_text = error_text

    reason = decide_reason(final_text, returncode)
    summary_lines = [
        "[codex-adapter] invoked Codex: " + ("yes" if codex_invoked else "no"),
        f"[codex-adapter] continuation: {str(continuation).lower()}",
        f"[codex-adapter] codex return code: {returncode}",
        f"[codex-adapter] raw stdout log: {raw_stdout_path}",
        f"[codex-adapter] raw stderr log: {raw_stderr_path}",
    ]
    if error_text:
        summary_lines.append(f"[codex-adapter] adapter error: {error_text}")
    if final_text:
        summary_lines.append(final_text)
    else:
        summary_lines.append("[codex-adapter] no Codex final text was captured")
    summary_lines.append(f"END_REASON:{reason}")

    result_obj = {
        "type": "result",
        "result": "\n".join(summary_lines),
        "adapter": {
            "run_id": run_id,
            "continuation": continuation,
            "codex_invoked": codex_invoked,
            "codex_returncode": returncode,
            "raw_stdout_log": str(raw_stdout_path),
            "raw_stderr_log": str(raw_stderr_path),
            "final_message_log": str(final_message_path),
        },
    }
    result_path.write_text(json.dumps(result_obj, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result_obj, ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
