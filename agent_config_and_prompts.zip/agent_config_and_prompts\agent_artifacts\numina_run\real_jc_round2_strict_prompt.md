This is a strict repair iteration after a previous round used a suspicious Newton shortcut.

You are running through Numina-Lean-Agent via a Codex wrapper.

Work only on `Formalization.lean` in the current Lean project directory.
Do not edit `Formalization.lean.bak_step8ea`.
Do not edit `Formalization.lean.bak_step8eb_restored`.
Do not edit `NuminaAdapterToy.lean`.
Do not edit any files outside this Lean project.

Target theorem:

```lean
AI4MATH.jordan_chevalley_decomposition
```

Required preservation:

- Preserve the theorem name `AI4MATH.jordan_chevalley_decomposition`.
- Preserve the exact mathematical meaning of the theorem statement.
- Do not weaken the theorem statement.
- Keep the finite-dimensional vector space hypothesis.
- Keep the algebraically closed field hypothesis.
- Keep `T : Module.End K V`.
- Keep existence of `S N`.
- Keep `T = S + N`.
- Keep `S.IsSemisimple`.
- Keep `IsNilpotent N`.
- Keep `Commute S N`.
- Keep both polynomial-in-`T` membership goals:
  `S in Algebra.adjoin K ({T} : Set (Module.End K V))`
  and
  `N in Algebra.adjoin K ({T} : Set (Module.End K V))`.
- Keep the uniqueness clause for any `S' N'` satisfying the same decomposition conditions.

Strict forbidden rules:

- Do not import `Mathlib.LinearAlgebra.JordanChevalley`.
- Do not use `Module.End.exists_isNilpotent_isSemisimple`.
- Do not use `Module.End.isNilpotent_isSemisimple_unique`.
- Do not use `Module.End.exists_isNilpotent_isSemisimple_of_separable_of_dvd_pow`.
- Do not use any theorem, lemma, alias, wrapper, or import that directly states Jordan-Chevalley decomposition, Jordan-Chevalley-Dunford decomposition, Dunford decomposition, existence of a semisimple plus nilpotent decomposition, or uniqueness of such a decomposition.
- Do not use any direct wrapper around Mathlib's built-in Jordan-Chevalley theorem.
- Do not introduce custom `axiom`, `constant`, or `unsafe`.
- Do not use `admit`.
- Do not leave `sorry`.

Additional strict forbidden constraints for this repair iteration:

- Do not import `Mathlib.Dynamics.Newton`.
- Do not use `Polynomial.existsUnique_nilpotent_sub_and_aeval_eq_zero`.
- Do not use `Module.End.eq_zero_of_isNilpotent_isSemisimple`.
- Do not use any theorem whose documentation or name directly says it proves Jordan-Chevalley, Dunford decomposition, or semisimple-plus-nilpotent existence/uniqueness.

Why this repair iteration exists:

- A previous one-round run produced a Lean-accepted proof, but it imported `Mathlib.Dynamics.Newton`.
- That proof used `Polynomial.existsUnique_nilpotent_sub_and_aeval_eq_zero`.
- Mathlib's own `LinearAlgebra/JordanChevalley.lean` uses that Newton lemma internally.
- This repair round must avoid that shortcut and follow the lower-level blueprint route instead.

Preferred proof strategy:

Follow `../inputs/blueprint.md` and the lower-level building blocks in `../logs/MATHLIB_BUILDING_BLOCKS.md`.

Prefer adding helper lemmas above the theorem if useful.

The blueprint route is:

1. Prove scalar plus nilpotent is invertible.
2. Compare generalized eigenspaces and eigenspaces under a commuting semisimple/nilpotent decomposition.
3. Use generalized eigenspace decomposition.
4. Use the Chinese Remainder Theorem to construct a polynomial `p`.
5. Define `S = p(T)` and `N = T - p(T)`.
6. Prove `S` is semisimple.
7. Prove `N` is nilpotent.
8. Prove `S` and `N` commute.
9. Prove uniqueness.

Allowed lower-level themes include:

- `LinearMap`
- `Module.End`
- `Submodule`
- `Polynomial`
- `Ideal`
- finite-dimensional vector spaces
- kernels
- direct sums
- polynomial evaluation on endomorphisms
- nilpotent maps
- semisimple / diagonalizable definitions
- generalized eigenspaces
- ordinary tactics

Workflow:

1. Inspect the existing imports and theorem statement.
2. Make conservative Lean edits only in `Formalization.lean`.
3. After edits, run:

```text
lake env lean Formalization.lean
```

4. Check placeholders / unsafe declarations:

```text
rg -n "sorry|admit|axiom|constant|unsafe" Formalization.lean
```

5. Check exact forbidden and strict-forbidden names:

```text
rg -n "Mathlib.LinearAlgebra.JordanChevalley|exists_isNilpotent_isSemisimple|isNilpotent_isSemisimple_unique|exists_isNilpotent_isSemisimple_of_separable_of_dvd_pow|Dunford|Mathlib.Dynamics.Newton|existsUnique_nilpotent_sub_and_aeval_eq_zero|eq_zero_of_isNilpotent_isSemisimple" Formalization.lean
```

End protocol:

- Use `END_REASON:COMPLETE` only if `Formalization.lean` has:
  - no Lean errors;
  - no `sorry`;
  - no `admit`;
  - no `axiom`, `constant`, or `unsafe`;
  - no exact forbidden names;
  - no strict-forbidden Newton or semisimple-nilpotent shortcut names;
  - theorem statement preserved.
- If the theorem cannot be completed under these strict constraints, make honest partial progress while preserving the theorem statement and end with `END_REASON:LIMIT`.
