# Step 8C-B Archon-to-Codex Backend Plan

## Chosen Route

Route B4: Not feasible in reasonable time.

## Evidence

The Step 8C-A investigation found that Codex CLI is installed and usable. `codex.cmd --version` reports `codex-cli 0.132.0`, and `codex.cmd exec --help` confirms that Codex supports non-interactive prompt execution, stdin prompts, working-directory selection with `--cd`, and JSONL output with `--json`.

However, the same investigation found that Archon v0.2.0 has no native Codex backend switch. Archon's central coding-agent wrapper is `ClaudeAgent` in `agent_artifacts/archon_run/Archon/src/archon/agent.py`, and the plan, prover, review, subagent, and merge paths instantiate `ClaudeAgent` directly.

Archon currently depends on Claude Code-specific behavior in several places:

- Claude-specific command flags such as `--dangerously-skip-permissions`, `--permission-mode bypassPermissions`, and `--output-format stream-json`;
- Claude stream-json event parsing in `agent.py`;
- Claude session IDs and resume behavior;
- Claude authentication checks in preflight and doctor commands;
- `.claude/` project tooling, MCP setup, plugins, and subagent wrappers;
- dashboard/log assumptions about Claude event fields and usage/cost metadata.

The investigation also found that OpenAI, Gemini, and OpenRouter keys are treated as optional informal-agent keys, not as coding-agent backend credentials. The non-Anthropic proving lanes supported by Archon are Kimi/Moonshot and DeepSeek, and those still route through Claude Code using Anthropic-compatible environment variables.

## Why Native Configuration Is Not Available

Archon's CLI and config expose `--model`, but this changes the model/provider used by Claude Code. It does not change the backend executable to Codex.

The Archon help text lists Anthropic aliases such as `opus`, `sonnet`, and `haiku`, plus non-Anthropic provider aliases such as `kimi` and `deepseek`. The code passes the resolved model into `ClaudeAgent`, which then invokes Claude Code. No CLI flag or `.archon/config.json` setting was found for selecting `codex.cmd` as the coding-agent executable.

## Why a Small Patch Is Not Safe

Replacing the string `claude` with `codex.cmd` is insufficient. Archon does not merely shell out to an arbitrary assistant and read a final text response. It expects Claude Code's command-line contract, event stream, project tooling, and session model.

In particular, Archon expects Claude-specific stream-json events, Claude session IDs, Claude `--resume` behavior, Claude authentication checks, and `.claude/` MCP/plugin/subagent tooling. Codex has its own non-interactive CLI and JSONL mode, but its output schema and runtime semantics are not the same as Claude Code's.

A small string replacement could make a process start, but it would likely break event parsing, session logging, resume, dashboard reporting, MCP/tool behavior, or subagent coordination.

## Risk Assessment

Risk: high.

The risk is high because the backend coupling affects the main execution path and also the monitoring, resume, setup, and subagent systems. A partial adapter could appear to run while silently losing important correctness and reporting behavior.

## Decision

We should not patch Archon for this assignment. The patch needed to repoint Archon v0.2.0 to Codex is likely larger than the formalization task itself and would introduce substantial new failure modes.

## Next Recommended Step

Try `numina-lean-agent` or another Lean proving agent harness that can be repointed to Codex more easily.

If Numina also cannot be repointed, then use a Codex-driven Lean loop as a final fallback, while clearly documenting the reason.

## Report Wording

I first installed and initialized Archon. However, Archon's default proof loop depends on Claude Code. Because Claude Code authentication was unavailable, I investigated whether Archon could be repointed to Codex, as the assignment notes that such harnesses can be agent-agnostic. The investigation showed that this Archon version has no native Codex backend and is tightly coupled to Claude-specific stream-json output, session handling, and `.claude/` tooling. Therefore, repointing Archon to Codex would require a large patch and was not feasible within the assignment time. I then proceeded to try another Lean proving-agent route / fallback workflow.

