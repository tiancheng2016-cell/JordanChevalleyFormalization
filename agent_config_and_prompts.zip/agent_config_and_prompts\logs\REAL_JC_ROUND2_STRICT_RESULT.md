# Step 8E-B Strict Repair Round Result

## Why This Repair Round Was Needed

Step 8E-A technically completed the theorem: `lake env lean Formalization.lean` accepted the file, the file contained no `sorry` or `admit`, and the exact forbidden-name search passed.

However, Step 8E-A introduced suspicious / too-close dependencies:

```text
Mathlib.Dynamics.Newton
Polynomial.existsUnique_nilpotent_sub_and_aeval_eq_zero
Module.End.eq_zero_of_isNilpotent_isSemisimple
```

The Newton lemma is used internally by Mathlib's own `LinearAlgebra/JordanChevalley.lean`, so the Step 8E-A result was not submitted as final. This strict repair round restored the pre-round-1 backup and reran Numina/Codex with those Newton and semisimple-nilpotent shortcut names explicitly forbidden.

## Iteration / Steering Record

This was the second real theorem iteration and a steering/repair step.

The steering change was:

- restore `lean_project/Formalization.lean.bak_step8ea`;
- forbid `Mathlib.Dynamics.Newton`;
- forbid `Polynomial.existsUnique_nilpotent_sub_and_aeval_eq_zero`;
- forbid `Module.End.eq_zero_of_isNilpotent_isSemisimple`;
- ask the agent to follow the blueprint route using generalized eigenspaces, CRT, polynomial evaluation, nilpotence, semisimplicity, commutation, and uniqueness.

## Baseline After Restoration

The real file was restored:

```text
Copy-Item lean_project/Formalization.lean.bak_step8ea lean_project/Formalization.lean
```

A fresh repair backup was created:

```text
lean_project/Formalization.lean.bak_step8eb_restored
```

Baseline Lean check:

```text
lake env lean Formalization.lean
Formalization.lean:19:8: warning: declaration uses `sorry`
```

Baseline placeholder / unsafe search:

```text
rg -n "sorry|admit|axiom|constant|unsafe" Formalization.lean
35:  sorry
```

Baseline strict forbidden-name search:

```text
rg -n "Mathlib.LinearAlgebra.JordanChevalley|exists_isNilpotent_isSemisimple|isNilpotent_isSemisimple_unique|exists_isNilpotent_isSemisimple_of_separable_of_dvd_pow|Dunford|Mathlib.Dynamics.Newton|existsUnique_nilpotent_sub_and_aeval_eq_zero|eq_zero_of_isNilpotent_isSemisimple" Formalization.lean
```

Output: no matches.

## Numina Command Used

Strict prompt:

```text
agent_artifacts/numina_run/real_jc_round2_strict_prompt.md
```

Strict config:

```text
agent_artifacts/numina_run/real_jc_round2_strict_config.yaml
```

The config targeted only:

```text
../../../lean_project/Formalization.lean
```

The command was run from:

```text
agent_artifacts/numina_run/numina-lean-agent/
```

Command:

```powershell
$env:PYTHONPATH='..\python_deps'
$wrapper=(Resolve-Path ..\wrappers).Path
$env:PATH="$wrapper;$env:PATH"
$env:NUMINA_CLAUDE_EXE='python'
$env:NUMINA_CLAUDE_ADAPTER=(Resolve-Path ..\wrappers\claude_codex_adapter.py).Path
python -m scripts.run_claude batch ..\real_jc_round2_strict_config.yaml
```

## Wrapper / Codex Invocation Status

Numina started one task:

```text
file_Formalization_20260613_125912
```

Numina result:

```text
Success: True
End reason: COMPLETE
Rounds used: 1
```

Result artifact:

```text
agent_artifacts/numina_run/results/real_jc_round2_strict/file_Formalization_20260613_125912/result.json
```

Important adapter caveat:

```text
[codex-adapter] invoked Codex: yes
[codex-adapter] continuation: false
[codex-adapter] codex return code: 1
[codex-adapter] adapter error: TimeoutExpired ... timed out after 600 seconds
```

Codex wrote a final message before the timeout:

```text
Implemented the repair in Formalization.lean.
lake env lean Formalization.lean passes with no errors or warnings.
rg placeholder search returned no matches.
Forbidden-name scan returned no matches.
END_REASON:COMPLETE
```

Because the adapter timed out, it appended `END_REASON:LIMIT` after Codex's final `END_REASON:COMPLETE`. Numina parsed the task as complete, but this report relies on independent post-run Lean and grep checks rather than the wrapper status alone.

## Formalization.lean Changes

`Formalization.lean` was modified from the restored backup.

Diff summary:

- imports remained targeted;
- no `Mathlib.Dynamics.Newton` import was added;
- two private helper lemmas were added:
  - `maxGenEigenspace_eq_bot_of_not_hasEigenvalue`;
  - `aeval_sub_C_apply_eq_zero_of_mem_maxGen`;
- the theorem statement was preserved;
- the single `sorry` proof was replaced by a full proof;
- the proof uses generalized eigenspaces, CRT via `Ideal.exists_forall_sub_mem_ideal`, polynomial evaluation, nilpotence on generalized eigenspaces, squarefree-annihilator semisimplicity, and a uniqueness argument through generalized eigenspaces.

Noteworthy declarations used:

```text
Ideal.exists_forall_sub_mem_ideal
Module.End.iSup_maxGenEigenspace_eq_top
Module.End.isSemisimple_of_squarefree_aeval_eq_zero
Module.End.apply_eq_of_mem_of_comm_of_isFinitelySemisimple_of_isNil
```

Source review note:

- `Ideal.exists_forall_sub_mem_ideal` is a Chinese Remainder Theorem corollary.
- `Module.End.apply_eq_of_mem_of_comm_of_isFinitelySemisimple_of_isNil` is in `Mathlib.LinearAlgebra.Eigenspace.Semisimple`; the file describes lower-level eigenspace results for semisimple endomorphisms, not a Jordan-Chevalley existence or uniqueness theorem.
- `Module.End.isSemisimple_of_squarefree_aeval_eq_zero` is a lower-level semisimplicity criterion already recorded in `logs/MATHLIB_BUILDING_BLOCKS.md`.

## Lean Check After Strict Round

Command:

```text
lake env lean Formalization.lean
```

Output:

```text
no output
```

Result: Lean accepts the file with no errors and no warnings.

## Placeholder Search After Strict Round

Command:

```text
rg -n "sorry|admit|axiom|constant|unsafe" Formalization.lean
```

Output:

```text
no matches
```

Additional exact count check:

```text
sorry=0
admit=0
axiom=0
constant=0
unsafe=0
```

## Strict Forbidden Name Search After Strict Round

Command:

```text
rg -n "Mathlib.LinearAlgebra.JordanChevalley|exists_isNilpotent_isSemisimple|isNilpotent_isSemisimple_unique|exists_isNilpotent_isSemisimple_of_separable_of_dvd_pow|Dunford|Mathlib.Dynamics.Newton|existsUnique_nilpotent_sub_and_aeval_eq_zero|eq_zero_of_isNilpotent_isSemisimple" Formalization.lean
```

Output:

```text
no matches
```

Additional exact count check:

```text
Mathlib.LinearAlgebra.JordanChevalley=0
exists_isNilpotent_isSemisimple=0
isNilpotent_isSemisimple_unique=0
exists_isNilpotent_isSemisimple_of_separable_of_dvd_pow=0
Dunford=0
Mathlib.Dynamics.Newton=0
existsUnique_nilpotent_sub_and_aeval_eq_zero=0
eq_zero_of_isNilpotent_isSemisimple=0
```

## Theorem Statement Preservation

The theorem statement was preserved.

Evidence:

- Numina statement tracker reported `"statement_changes": []`.
- The diff against `Formalization.lean.bak_step8eb_restored` shows the theorem name and statement unchanged.
- The theorem still states existence of `S N`, `T = S + N`, `S.IsSemisimple`, `IsNilpotent N`, `Commute S N`, both polynomial-in-`T` membership clauses, and uniqueness.

The theorem was not weakened.

## Result Assessment

Technical result: COMPLETE by independent Lean and grep checks.

Reason:

- strict repair round started;
- wrapper invoked: yes;
- Codex invoked: yes;
- Numina used 1 round;
- `Formalization.lean` was modified;
- theorem statement was preserved;
- theorem was not weakened;
- independent `lake env lean Formalization.lean` passes with no output;
- remaining `sorry`: 0;
- remaining `admit`: 0;
- custom `axiom` / `constant` / `unsafe`: no matches;
- exact forbidden names: no matches;
- strict-forbidden Newton/shortcut names: no matches.

Caveat:

- the adapter hit its 600-second timeout after Codex had written a final COMPLETE message;
- the adapter result JSON therefore contains both Codex's `END_REASON:COMPLETE` and the adapter's appended `END_REASON:LIMIT`;
- Numina still recorded `COMPLETE`, but the trustworthy basis for this result is the independent Lean and grep verification above.

## Next Recommended Step

Proceed to final verification only after reviewing the strict proof surface.

Suggested next step:

1. Run final `lake env lean Formalization.lean`.
2. Run final searches over Lean files for `sorry`, `admit`, `axiom`, `constant`, `unsafe`, exact forbidden names, and strict-forbidden shortcut names.
3. Add or run `#print axioms AI4MATH.jordan_chevalley_decomposition`.
4. Save exact `#print axioms` output.
5. Prepare the final report, explicitly documenting:
   - round 1 completed but was rejected for the Newton shortcut;
   - round 2 was a strict repair iteration;
   - the adapter timeout caveat;
   - the independent final verification outputs.
