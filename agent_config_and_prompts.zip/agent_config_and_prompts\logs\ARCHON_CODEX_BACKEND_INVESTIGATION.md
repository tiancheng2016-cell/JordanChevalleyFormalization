# Step 8C Archon Codex Backend Investigation

## Current Blocker

Archon currently stops before the proof loop can run because Claude Code is not authenticated. The direct check:

```text
claude.cmd -p "reply with OK" --no-session-persistence
```

returned:

```text
Not logged in · Please run /login
```

The Step 8 `archon loop` attempt also stopped before iteration 1. Archon additionally reports that the project state is still `init`, because the semantic init pass normally expects Claude Code to finish the init-stage handoff.

## Codex CLI Availability

`codex.cmd` is available through PowerShell command resolution:

```text
Get-Command codex.cmd
Name: codex.cmd
Source: C:\Users\tianc\AppData\Roaming\npm\codex.cmd
CommandType: Application
```

The requested `where.exe codex` command returned:

```text
c:\Users\tianc\.vscode\extensions\openai.chatgpt-26.609.30741-win32-x64\bin\windows-x86_64\codex.exe
```

`where.exe codex.cmd` did not find the npm shim, even though PowerShell can run it:

```text
INFO: Could not find files for the given pattern(s).
```

Version:

```text
codex.cmd --version
codex-cli 0.132.0
```

The top-level help shows that Codex supports non-interactive operation:

```text
codex exec            Run Codex non-interactively
```

`codex.cmd exec --help` confirms that the prompt may be passed as an argument or read from stdin, and that JSONL output is available:

```text
Usage: codex exec [OPTIONS] [PROMPT]
Initial instructions for the agent. If not provided as an argument (or if `-` is used), instructions are read from stdin.
--json    Print events to stdout as JSONL
--cd <DIR>    Tell the agent to use the specified directory as its working root
--model <MODEL>    Model the agent should use
```

This means Codex has the basic CLI capability needed for a non-interactive agent backend, but it does not mean it is drop-in compatible with Archon's current Claude Code event parser and session model.

## Archon Backend Architecture

Archon v0.2.0 is currently built around Claude Code as the coding-agent executable.

Important source findings:

- `src/archon/agent.py` is explicitly the central Claude wrapper. It defines `ClaudeAgent`, builds `claude` command lines, and all core phases use it.
- `ClaudeAgent._build_flags` emits Claude-specific flags:

```text
--dangerously-skip-permissions
--permission-mode bypassPermissions
--model <model>
```

- `ClaudeAgent.run` constructs a headless Claude call:

```text
claude -p <prompt> ...
```

- With logging enabled, `ClaudeAgent._run_with_logging` appends:

```text
--verbose --output-format stream-json
```

and then parses Claude Code's stream-json output with an embedded parser.

- The embedded parser in `agent.py` expects Claude Code event shapes: top-level `session_id`, event `type` values like `assistant`, `user`, and `result`, assistant content blocks such as `thinking`, `text`, and `tool_use`, and `result` fields such as `total_cost_usd`, `duration_ms`, `num_turns`, and `usage`.

- `src/archon/session_log.py` reads normalized `session_end` rows produced from Claude Code output and classifies run success/failure from those rows.

- `src/archon/commands/loop/preflight.py` checks for Claude Code and runs:

```text
claude -p "reply with OK" --no-session-persistence
```

- `src/archon/commands/doctor.py` has a `ClaudeCodeDoctorCheck`, checks Claude installation/authentication, and checks `.claude/` project configuration.

- `src/archon/commands/init/steps/semantic_pass.py` hands the init semantic pass to `ClaudeAgent(...).run_interactive(...)`.

- The loop phases call `ClaudeAgent` directly:

```text
commands/loop/phases/plan.py      -> ClaudeAgent(..., role="plan").run(...)
commands/loop/prover/runners.py   -> ClaudeAgent(..., role="prover").run(...)
commands/loop/phases/review.py    -> ClaudeAgent(..., role="review").run(...)
subagents/base.py                 -> ClaudeAgent(..., role=<subagent>).run(...)
multilane/merge_agent.py          -> ClaudeAgent(..., role="merge").run(...)
```

- Resume support is Claude-specific. `commands/loop/resume.py` looks for Claude session logs under:

```text
~/.claude/projects/<sanitized-cwd>/<session_id>.jsonl
```

and passes `--resume <id>` to Claude.

- Init/setup also use Claude-specific MCP/plugin layout:

```text
.claude/
.claude/tools/
.claude-plugin/plugin.json
claude mcp ...
claude plugin ...
```

## Native Backend Configuration

Does Archon already support selecting Codex through config or CLI?

No. I found no native `codex` backend setting in the CLI help or source search. The only source hit for `codex` is a comment in `env_loader.py` saying OpenAI/Gemini lanes were dropped because those models work better in their native CLIs, including `codex`.

Does `--model` only change the Claude model, or can it change the whole backend?

`--model` does not change the executable backend. It is passed into `ClaudeAgent` and ultimately to Claude Code as `--model <model>`. Archon recognizes Anthropic aliases such as `opus`, `sonnet`, `haiku`, and two non-Anthropic aliases, `kimi` and `deepseek`, but those still use Claude Code as the driver with Anthropic-compatible environment variables.

The help text says:

```text
--model TEXT
Model used for every plan / prover / review phase.
Anthropic aliases: 'opus', 'sonnet', 'haiku' or a full id.
Non-Anthropic providers: 'kimi', 'deepseek'.
```

Are OpenAI/Gemini/OpenRouter keys used only for informal agents, or for the coding agent too?

They are used only for the informal agent. `commands/tooling/env_loader.py`, `commands/setup/checks/api_keys.py`, and `commands/doctor.py` describe `OPENAI_API_KEY`, `GEMINI_API_KEY`, and `OPENROUTER_API_KEY` as optional informal-agent keys. They are not used to drive the main plan/prover/review coding agent.

For main proving lanes, Archon supports only:

```text
moonshot / kimi via MOONSHOT_API_KEY
deepseek via DEEPSEEK_API_KEY
anthropic via Claude Code login
```

and the non-Anthropic lanes are still routed through Claude Code using:

```text
ANTHROPIC_BASE_URL
ANTHROPIC_AUTH_TOKEN
ANTHROPIC_MODEL
```

## Patch Feasibility

Classification: Large patch required.

A very small proof-of-concept might be possible by replacing `ClaudeAgent` with a Codex-backed wrapper that calls something like:

```text
codex.cmd exec --json --cd <project> <prompt>
```

However, a reliable Archon backend swap is larger than changing one command string. The current code depends on Claude Code behavior in several places:

- Claude-specific command flags and output format;
- Claude stream-json event schema and Archon's normalized JSONL parser;
- Claude session IDs and `--resume`;
- Claude authentication preflight and doctor checks;
- `.claude/` MCP/plugin/tool layout;
- subagent dispatch instructions that reference `.claude/tools`;
- multilane provider settings that route through Claude Code's Anthropic-compatible environment variables;
- dashboard/log assumptions about Claude event fields and cost/usage metadata.

So Codex is available locally, but Archon does not appear to have a native Codex backend switch. Repointing it robustly would require introducing a backend abstraction or a Codex adapter that emits Archon's expected normalized events.

## Risks

- Codex JSONL output may not match Claude Code's `--output-format stream-json` schema. Archon's parser expects Claude event names and fields.
- Codex session/resume semantics differ from Claude Code's `--resume <id>` and `~/.claude/projects/...` storage.
- Claude-specific MCP/plugin setup under `.claude/` would not automatically become Codex MCP/plugin setup.
- Archon's subagent prompts and wrappers mention `.claude/tools`, so subagent dispatch may fail or need redesign.
- Doctor/preflight would need to check Codex auth and runtime health instead of Claude auth.
- Permission/sandbox flags differ: Claude's `--permission-mode bypassPermissions` and `--dangerously-skip-permissions` are not Codex flags.
- Even if a Codex adapter can run plan/prover/review prompts, dashboard cost/token/session reporting may need schema translation.
- A partial patch could appear to run but silently lose important behavior such as session logging, resume, tool-call display, or subagent coordination.

