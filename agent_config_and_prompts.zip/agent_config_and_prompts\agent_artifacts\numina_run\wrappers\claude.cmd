@echo off
python "%~dp0claude_codex_adapter.py" %*
