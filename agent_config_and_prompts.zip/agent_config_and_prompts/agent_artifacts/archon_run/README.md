# Step 7 Archon Setup

This folder contains the Archon setup artifacts for the Jordan-Chevalley formalization.

## Official Archon Source

- Repository: `https://github.com/FrenzyMath/Archon`
- Installed CLI version: `0.2.0`
- Local checkout: `agent_artifacts/archon_run/Archon`

## Target

- Lean project: `lean_project/`
- Lake file: `lean_project/lakefile.toml`
- Target file: `lean_project/Formalization.lean`
- Main theorem: `AI4MATH.jordan_chevalley_decomposition`

## Setup Status

- Archon CLI installed.
- Claude Code installed because Archon init requires it.
- Archon initialized for `lean_project/`.
- Assignment-specific config stored in `ARCHON_CONFIG.json`.
- Assignment-specific instructions stored in `ARCHON_INSTRUCTIONS.md`.
- The theorem signature is protected in `lean_project/archon-protected.yaml`.
- Archon proof loop has not been started.
- The proof has not been attempted.

## Future Command

Do not run this during Step 7:

```text
archon loop lean_project
```
