# Archon Instructions

Target Lean project: `lean_project/`

Target file: `Formalization.lean`

Main theorem: `AI4MATH.jordan_chevalley_decomposition`

Source natural-language proof: `inputs/blueprint.md`

User hints: `agent_artifacts/archon_task/USER_HINTS.md`

Forbidden theorem rules: `agent_artifacts/archon_task/FORBIDDEN_THEOREMS.md`

Mathlib building-block survey: `logs/MATHLIB_BUILDING_BLOCKS.md`

## Required Strategy

- Follow the proof plan in `inputs/blueprint.md`.
- Use only lower-level Mathlib building blocks.
- Use Lean kernel diagnostics to repair proof attempts.
- Preserve the theorem statement and do not weaken it.
- The declaration `AI4MATH.jordan_chevalley_decomposition` is protected in `lean_project/archon-protected.yaml`.

## Forbidden

- Do not import `Mathlib.LinearAlgebra.JordanChevalley`.
- Do not use `Module.End.exists_isNilpotent_isSemisimple`.
- Do not use `Module.End.isNilpotent_isSemisimple_unique`.
- Do not use any theorem, lemma, alias, or wrapper that directly states Jordan-Chevalley decomposition, Jordan-Chevalley-Dunford decomposition, Dunford decomposition, existence of a semisimple plus nilpotent decomposition, or uniqueness of such a decomposition.
- Do not finish the proof using a direct wrapper around Mathlib's built-in Jordan-Chevalley theorem.
- Do not introduce custom axioms.
- Do not leave `sorry` or `admit` in the final file.

## Step 7 Stop Line

Archon initialization is allowed. The Archon proof loop must not be started in Step 7.
