# Prompts For Final Report

This file summarizes actual prompts used in the workflow. Full user prompts are stored in `logs/PROMPTS.md`. Generated agent prompts are stored in the specific artifact files listed below.

## Setup / Project Preparation Prompt

Step name: Steps 1-2 project preparation and instruction files.

Purpose: Create the project folders, initialize logs, append prompts, and create Archon task instruction files before Lean or Archon setup.

Exact prompt file/source:

```text
logs/PROMPTS.md
```

Excerpt:

```text
Please do only project-folder preparation.
Confirm that these folders exist: inputs, logs, agent_artifacts/archon_task, lean_project, report.
Create logs/PROMPTS.md and logs/RUN_LOG.md.
Do not set up Lean yet.
Do not write Formalization.lean yet.
Do not start Archon yet.
```

Full prompt available in `logs/PROMPTS.md`: yes.

## Archon Setup / Archon-to-Codex Investigation Prompt

Step name: Step 7 Archon setup, Step 8 Archon run attempt, and Steps 8C-A/8C-B Archon-to-Codex investigation.

Purpose: Install and initialize Archon, attempt to run its proof loop, then investigate and document whether Archon could be repointed from Claude Code to Codex.

Exact prompt file/source:

```text
logs/PROMPTS.md
agent_artifacts/archon_run/ARCHON_CONFIG.json
agent_artifacts/archon_run/ARCHON_INSTRUCTIONS.md
logs/ARCHON_CODEX_BACKEND_INVESTIGATION.md
logs/ARCHON_CODEX_BACKEND_PLAN.md
```

Excerpt:

```text
Do not run the Archon proof loop yet.
Locate or install Archon.
Initialize Archon for the Lean project at lean_project/.
The config must tell Archon the target file Formalization.lean and main theorem AI4MATH.jordan_chevalley_decomposition.

Investigate whether this local Archon installation can call codex.cmd instead of Claude Code.
Do not patch anything yet.
```

Full prompt available in `logs/PROMPTS.md`: yes.

## Numina-to-Codex Investigation Prompt

Step name: Steps 8D-A and 8D-B Numina-to-Codex investigation and wrapper plan.

Purpose: Investigate Numina-Lean-Agent as a fallback proving harness and choose an implementation route for using Codex through a wrapper adapter.

Exact prompt file/source:

```text
logs/PROMPTS.md
logs/NUMINA_CODEX_BACKEND_INVESTIGATION.md
logs/NUMINA_CODEX_WRAPPER_PLAN.md
```

Excerpt:

```text
Investigate whether Numina-Lean-Agent can be repointed from Claude Code to Codex.
Do not modify Formalization.lean.
Do not run a final proof loop yet.

The recommended route from Step 8D-A is N3: Create a wrapper adapter around codex.cmd exec.
This step is planning only.
```

Full prompt available in `logs/PROMPTS.md`: yes.

## Wrapper Adapter / Toy Dry-Run Prompt

Step name: Step 8D-C Numina-to-Codex wrapper adapter and toy dry runs.

Purpose: Implement the wrapper adapter, create a Windows shim, run smoke tests, and run a toy Numina/Codex dry run on `NuminaAdapterToy.lean` only.

Exact prompt file/source:

```text
logs/PROMPTS.md
agent_artifacts/numina_run/adapter_toy_prompt.md
agent_artifacts/numina_run/adapter_toy_config.yaml
logs/NUMINA_CODEX_WRAPPER_DRYRUN.md
```

Excerpt:

```text
Implement the Numina-to-Codex wrapper adapter and run only staged toy dry runs.
Do not modify lean_project/Formalization.lean.
Do not run the real Jordan-Chevalley proof loop.
The toy prompt must explicitly say: only edit NuminaAdapterToy.lean; replace the toy sorry with a valid proof.
```

Full prompt available in `logs/PROMPTS.md`: yes.

## Real Theorem Round 1 Prompt

Step name: Step 8E-A controlled one-round real Jordan-Chevalley Numina/Codex test.

Purpose: Run one bounded real theorem test using Numina/Codex, preserving the theorem statement and existing forbidden theorem constraints.

Exact prompt file/source:

```text
logs/PROMPTS.md
agent_artifacts/numina_run/real_jc_round1_prompt.md
agent_artifacts/numina_run/real_jc_round1_config.yaml
logs/REAL_JC_ROUND1_RESULT.md
```

Excerpt:

```text
Run only one Numina/Codex round in this step.
Work only on lean_project/Formalization.lean.
Preserve the theorem name AI4MATH.jordan_chevalley_decomposition.
Do not use forbidden Mathlib Jordan-Chevalley / Dunford declarations.
Use END_REASON:COMPLETE only if Formalization.lean has no Lean errors, no sorry, no admit, no custom axiom, and no forbidden theorem usage.
```

Full prompt available in `logs/PROMPTS.md`: yes.

## Strict Repair Round 2 Prompt

Step name: Step 8E-B strict repair rerun after first real Jordan-Chevalley round.

Purpose: Reject the Step 8E-A proof because it used a suspicious Newton shortcut, restore the backup, and rerun with stricter constraints.

Exact prompt file/source:

```text
logs/PROMPTS.md
agent_artifacts/numina_run/real_jc_round2_strict_prompt.md
agent_artifacts/numina_run/real_jc_round2_strict_config.yaml
logs/REAL_JC_ROUND2_STRICT_RESULT.md
```

Excerpt:

```text
Do not submit the Step 8E-A proof as final.
Restore from lean_project/Formalization.lean.bak_step8ea before the strict rerun.
Do not import Mathlib.Dynamics.Newton.
Do not use Polynomial.existsUnique_nilpotent_sub_and_aeval_eq_zero.
Do not use Module.End.eq_zero_of_isNilpotent_isSemisimple.
Prefer the blueprint route: generalized eigenspaces, CRT polynomial construction, polynomial evaluation, semisimplicity, nilpotence, commutation, uniqueness.
```

Full prompt available in `logs/PROMPTS.md`: yes.
