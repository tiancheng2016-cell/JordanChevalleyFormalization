# Step 8D-B Numina-to-Codex Wrapper Plan

## Chosen Route

N3: Create a wrapper adapter around `codex.cmd exec`.

## Why N3 Is Chosen

Numina-Lean-Agent has no native Codex backend configuration in the cloned repository. A focused search found no `codex` or `Codex` references, and the CLI/config surface exposes no field for choosing a coding-agent executable.

Directly replacing `claude` with `codex.cmd` is unsafe because Numina passes Claude-specific flags:

```text
-p
--verbose
--output-format stream-json
--permission-mode bypassPermissions
-c
```

Codex does not accept that exact command shape, and Numina expects Claude-style stream JSON output. However, Numina's backend call is centralized in `scripts/runner.py`, so a wrapper can translate Numina's Claude-shaped command into Codex calls and emit the final Claude-like JSON result line that Numina expects.

## Numina Source Inspection

Relevant files inspected:

- `agent_artifacts/numina_run/numina-lean-agent/scripts/run_claude.py`
- `agent_artifacts/numina_run/numina-lean-agent/scripts/runner.py`
- `agent_artifacts/numina_run/numina-lean-agent/scripts/task.py`
- `agent_artifacts/numina_run/numina-lean-agent/scripts/lean_checker.py`

### First-Round Command Shape

In `scripts/runner.py`, `run_claude_session` builds:

```python
base = ["claude", "-p", "--verbose", "--output-format", "stream-json"]
if permission_mode:
    base += ["--permission-mode", permission_mode]
```

The first call is:

```python
run_claude_once(
    base + [prompt], env=env, cwd=cwd, json_save_path=_get_json_save_path(1),
)
```

So the effective first-round command is:

```text
claude -p --verbose --output-format stream-json --permission-mode bypassPermissions "<prompt>"
```

### Continuation Command Shape

When the loop continues without resetting the session, `scripts/runner.py` builds:

```python
cmd = ["claude", "-c", "-p", "--verbose", "--output-format", "stream-json"]
if permission_mode:
    cmd += ["--permission-mode", permission_mode]
run_claude_once(
    cmd + ["continue"], env=env, cwd=cwd, json_save_path=_get_json_save_path(rounds),
)
```

So the effective continuation command is:

```text
claude -c -p --verbose --output-format stream-json --permission-mode bypassPermissions continue
```

If no `END_REASON` is detected, or after too many consecutive `LIMIT`s, Numina starts a fresh call again with `base + [prompt]`.

### JSONL Output Handling

`run_claude_once` opens the configured JSONL save path and sends subprocess stdout/stderr into that file:

```python
with open(json_save_path, "w", encoding="utf-8") as stdout_target:
    proc = subprocess.Popen(
        args,
        stdout=stdout_target,
        stderr=subprocess.STDOUT,
        text=True,
        env=env or None,
        cwd=str(cwd) if cwd else None,
    )
    proc.wait()
```

After the subprocess exits, Numina reads the last nonempty line of that file.

### Expected Final Result Fields

Numina expects the final nonempty JSONL line to parse as JSON and satisfy:

```python
parsed.get("type") == "result"
```

It stores that parsed object as `claude_result`, reads the human-readable content from:

```python
result_text = parsed.get("result", "")
```

and then prints that result text to stdout.

For compatibility, the adapter must always end with a line shaped like:

```json
{"type":"result","result":"...END_REASON:..."}
```

Optional Claude usage fields can be omitted at first. Numina's `extract_claude_usage` tolerates missing usage data.

### END_REASON Handling

`scripts/runner.py` defines:

```python
PAT_REASON = re.compile(r"(?m)^\\s*END_REASON:(LIMIT|COMPLETE|SELECTED_TARGET_COMPLETE)\\s*$", re.I)
```

The runner searches the final `result` text for one of:

- `END_REASON:LIMIT`
- `END_REASON:COMPLETE`
- `END_REASON:SELECTED_TARGET_COMPLETE`

If the reason is `COMPLETE`, Numina runs the verification callback. If verification fails, it resends the original prompt. If the reason is `LIMIT`, it continues or resets depending on the consecutive limit count. If no reason is found, it repeats the prompt.

### `allow_sorry: false` Enforcement

`scripts/task.py` defaults:

```python
allow_sorry: bool = False
```

`scripts/runner.py` enforces it during `on_complete_callback`:

```python
if task.allow_sorry:
    errors = [f for f, e, _, _, _ in results if e]
else:
    errors = [f for f, e, s, _, _ in results if e or s]
```

So with `allow_sorry: false`, either Lean errors or sorry warnings cause verification failure.

The same `allow_sorry` filtering is also used in the final verification path when the loop reaches its round limit.

### `lake env lean` Verification

`scripts/lean_checker.py` finds the nearest ancestor containing `lean-toolchain`, then runs:

```python
subprocess.run(
    ["lake", "env", "lean", str(file_path)],
    capture_output=True,
    text=True,
    timeout=60,
    cwd=str(project_root),
)
```

It treats a nonzero exit code, stdout/stderr containing `error`, or stdout/stderr containing `sorry` as failure when `allow_sorry` is false.

## Wrapper Adapter Design

Create:

```text
agent_artifacts/numina_run/wrappers/claude_codex_adapter.py
```

Optionally also create a small Windows shim:

```text
agent_artifacts/numina_run/wrappers/claude.cmd
```

The shim would call:

```text
python agent_artifacts/numina_run/wrappers/claude_codex_adapter.py %*
```

Then prepend `agent_artifacts/numina_run/wrappers/` to `PATH` only for the Numina process. This lets `subprocess.Popen(["claude", ...])` resolve to the adapter without modifying Numina source. If the PATH shim is unreliable on Windows, make a backed-up small patch in `scripts/runner.py` to set the executable path explicitly.

### Adapter Responsibilities

The adapter should:

- accept the Claude-like arguments Numina passes;
- ignore or log Claude-only flags such as `--verbose`, `--output-format stream-json`, and `--permission-mode`;
- detect first calls by the absence of `-c`;
- detect continuation calls by the presence of `-c`;
- extract the prompt after `-p`;
- for first calls, run `codex.cmd exec`;
- for continuation calls, run `codex.cmd exec resume --last`;
- pass the prompt to Codex as stdin with `-` or as the final argument;
- use `--cd <DIR>` to set the working directory to the subprocess cwd when available;
- request Codex JSONL output with `--json` if useful;
- save raw Codex output under an adapter log directory;
- write a final Claude-compatible JSON line to stdout:

```json
{"type":"result","result":"<adapter summary and Codex final message>\nEND_REASON:LIMIT"}
```

or, only when Codex explicitly reports completion and the adapter has not observed failures:

```json
{"type":"result","result":"<adapter summary and Codex final message>\nEND_REASON:COMPLETE"}
```

The adapter must avoid silently claiming success. If Codex exits nonzero, if no final message can be extracted, or if the adapter is uncertain, it should emit `END_REASON:LIMIT` or an error-flavored result text rather than `END_REASON:COMPLETE`.

### Suggested Adapter Algorithm

1. Parse `sys.argv[1:]`.
2. Record the raw argument vector and working directory in an adapter log.
3. Remove Claude-only flags:
   - `--verbose`
   - `--output-format stream-json`
   - `--permission-mode <mode>`
4. Detect continuation:
   - `continuation = "-c" in args`
5. Extract the prompt:
   - find `-p`;
   - if the next meaningful positional argument exists, use it as the prompt;
   - for continuation calls, the prompt is usually `continue`.
6. Build Codex command:
   - first call: `codex.cmd exec --cd <cwd> --json -`
   - continuation: `codex.cmd exec resume --last --json -`
7. Send the prompt to Codex stdin.
8. Save raw Codex stdout/stderr to adapter logs.
9. Extract the final Codex assistant message if available.
10. Decide `END_REASON` conservatively:
    - `COMPLETE` only if Codex explicitly says it completed the requested task and process exit code is zero;
    - otherwise `LIMIT`.
11. Print exactly one final JSON result line to stdout after any optional intermediate JSONL/log lines.

### Logs

Store adapter logs under:

```text
agent_artifacts/numina_run/wrappers/logs/
```

Suggested files:

- `adapter_invocations.jsonl`
- `codex_raw_round_<timestamp>.jsonl`
- `codex_stderr_round_<timestamp>.txt`
- `adapter_result_round_<timestamp>.json`

## Dry-Run Test Plan Before Touching Jordan-Chevalley

Do not run this during Step 8D-B. This is the plan for a future step.

Create a harmless toy Lean file:

```text
lean_project/NuminaAdapterToy.lean
```

Example content:

```lean
import Mathlib

theorem numina_adapter_toy : True := by
  sorry
```

Use a toy prompt that explicitly tells Codex not to edit `Formalization.lean` and not to touch Jordan-Chevalley. For the first dry run, set `max_rounds: 1`, `allow_sorry: false`, and use `result_dir` under `agent_artifacts/numina_run/results/adapter_toy/`.

The dry run should test only:

- the wrapper/shim is invoked by Numina;
- Codex receives the prompt;
- Numina can parse the wrapper's final Claude-compatible JSON result line;
- Numina still calls `lake env lean` through `scripts/lean_checker.py`;
- `allow_sorry: false` detects the remaining `sorry` in the toy file if the wrapper/agent does not fix it.

Recommended staged dry runs:

1. Adapter-only smoke test: call `claude_codex_adapter.py` directly with a fake Numina command and confirm it emits the expected final JSON line.
2. Numina parser smoke test: use the PATH shim with a fake adapter mode that emits `END_REASON:COMPLETE` without editing the toy file, so `allow_sorry: false` should fail verification.
3. Codex wiring smoke test: allow the adapter to call `codex.cmd exec` on the toy file with `max_rounds: 1`.

Only after these toy checks should the adapter be considered for the real target.

## Rollback Plan

Before any future patch:

- create backups of any files to be modified, for example:

```text
scripts/runner.py.bak
scripts/task.py.bak
```

- or create a git branch inside:

```text
agent_artifacts/numina_run/numina-lean-agent/
```

Suggested branch:

```text
numina-codex-wrapper-experiment
```

Preferred integration order:

1. Try PATH shim first, because it avoids modifying Numina source.
2. If PATH shim fails, patch only the minimal executable selection in `scripts/runner.py`.
3. Keep `.bak` files or git branch commits before every source modification.
4. Never overwrite original Numina source without backup.

Potential small source issue to verify before running: `scripts/task.py` references `self.mcp_log_dir` in `__post_init__`, but the dataclass field is not declared in the inspected source. If this causes task construction to fail, repair it only with backup and log the patch.

## Final Safety Checks After Any Future Patch

From inside `lean_project/`:

```text
lake env lean Formalization.lean
```

Search for prohibited proof placeholders or unsafe declarations:

```text
rg -n "sorry|admit|axiom|constant|unsafe" Formalization.lean
```

Search forbidden theorem/import names:

```text
rg -n "Mathlib.LinearAlgebra.JordanChevalley|exists_isNilpotent_isSemisimple|isNilpotent_isSemisimple_unique|exists_isNilpotent_isSemisimple_of_separable_of_dvd_pow|Dunford" Formalization.lean
```

If the real theorem is ever completed, also obtain exact axiom output:

```lean
#print axioms AI4MATH.jordan_chevalley_decomposition
```

## Next Recommended Step

Implement the wrapper adapter and a `claude.cmd` PATH shim under `agent_artifacts/numina_run/wrappers/`, then perform only the staged toy dry runs. Do not point Numina at `lean_project/Formalization.lean` until the adapter invocation, JSONL compatibility, and `allow_sorry: false` behavior have been verified on `NuminaAdapterToy.lean`.
